const express = require('express');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.post('/registrar', (req, res) => {
  const nombre = req.body.nombre;
  const fechaNacimiento = new Date(req.body.fecha_nacimiento);
  const hoy = new Date();
  const edad = hoy.getFullYear() - fechaNacimiento.getFullYear();

  const usuario = `${nombre},${fechaNacimiento},${edad}\n`;

  fs.appendFile('usuarios.txt', usuario, (error) => {
    if (error) throw error;
    console.log(`Usuario registrado: ${usuario}`);
  });

  res.send(`¡Hola ${nombre}! Tienes ${edad} años.`);
});

//? info en url raiz para saber que todo esta OK
app.get('/', (req, res) => {
  res.status(200).send('Servidor Ok')
});

app.listen(port, () => {
  console.log(`Servidor web iniciado en el puerto ${port} `);
});